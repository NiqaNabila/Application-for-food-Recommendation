# Face-Recogntion-PyQt

Watch the full tutorial here: http://bit.ly/facepyqt

## Learn more AI and OpenCV GUI Design?

Enroll in our YOLOv4 PyQt Course here : 
https://www.augmentedstartups.com/yolov4-course


## To Install the Facial Recognition Libraries Dependencies

You will need the following:

```pip install dlib==19.18.0```

```pip install face-recognition```
